import redis
import time
a=redis.Redis(password="24729220a")
t=time.time()

# for x in range(300):
# 	a.lpush("gao2",x)
# print(time.time()-t)

for x in range(100000):
	a.lpop("gao")
	a.lpush("gao",x)
	#a.lset("gao2",0,x)
print(time.time()-t)